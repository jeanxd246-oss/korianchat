#version 150

#moj_import <minecraft:dynamictransforms.glsl>

in vec4 vertexColor;

out vec4 fragColor;

void main() {
    vec4 color = vertexColor;
    if (color.a == 0.0) {
        discard;
    }
    // Fondo translucido negro del chat (y similares) -> color/opacidad configurados
    if (color.r < 0.004 && color.g < 0.004 && color.b < 0.004 && color.a < 0.99) {
        color = vec4(0.0000, 0.0000, 0.0000, 1.0000);
    }
    fragColor = color * ColorModulator;
}
